# Offline shopping repair pack — audited against the current `main` branch

## Important: do not replace `src/lib/preview-data.ts` again

The current GitHub `main` branch already contains the offline-aware version of
`src/lib/preview-data.ts` (290 lines). Its new import is:

```ts
import {
  readOfflineCatalogue,
  saveCatalogueOffline,
} from "@/lib/offline-storage";
```

The reason that import is red is that `src/lib/offline-storage.ts` is not yet
present on the current `main` branch. This pack supplies that missing dependency.
Keep the current `preview-data.ts` as it is for this step.

The GitHub commit history confirms the only current change since the previous
baseline is `src/lib/preview-data.ts`; none of the other new offline files have
been added to `main`.

## Step 1 — clear the current red import

Create this new file exactly:

`src/lib/offline-storage.ts`

Use the file in this pack. Do not overwrite any existing file for this step.

This should resolve the missing-module underline for `@/lib/offline-storage`.
It is a dependency addition, not a replacement of a working file.

## Step 2 — add the remaining new files

Create these new files (none are replacements):

- `src/hooks/use-offline-image.ts`
- `src/components/OfflineImage.tsx`
- `src/components/OfflineStatusBanner.tsx`
- `public/offline.html`
- `public/service-worker.js`

The image hook in this corrected pack avoids starting an ordinary `<img>` load
and a second `fetch()` for the same image at the same time. If CORS prevents
saving a remote image, it falls back to the normal image URL while online.

## Step 3 — small, targeted additions to existing files

Do not replace any of these existing files.

### `src/routes/__root.tsx` (currently 474 lines)

Add this import beside the existing component imports:

```tsx
import { OfflineStatusBanner } from "@/components/OfflineStatusBanner";
```

Inside `RootComponent`, immediately after the existing `pathname` declaration,
add this effect. `useEffect` is already imported in this file.

```tsx
useEffect(() => {
  if (import.meta.env.DEV || !("serviceWorker" in navigator)) return;

  void navigator.serviceWorker.register("/service-worker.js", {
    scope: "/",
    updateViaCache: "none",
  }).catch((error) => {
    console.error("Service worker registration failed:", error);
  });
}, []);
```

In the existing JSX, render `<OfflineStatusBanner />` immediately after
`<WelcomeBanner />`. Do not move or replace the header, footer, navigation,
support buttons, or any existing root logic.

### `src/routes/index.tsx` (currently 682 lines)

Add these imports:

```tsx
import { fetchStoreCatalogue } from "@/lib/preview-data";
import { OfflineImage } from "@/components/OfflineImage";
```

Inside the existing `loadStorefront()` function, replace only the three direct
Supabase catalogue reads and their result handling with:

```tsx
try {
  const catalogue = await fetchStoreCatalogue();
  if (!active) return;

  setProducts(catalogue.products as Product[]);
  setCategories(catalogue.categories as Category[]);
  setBanners(catalogue.banners as Banner[]);
  setLoadError(false);
} catch (error) {
  console.error("Storefront catalogue could not be loaded:", error);
  if (active) setLoadError(true);
} finally {
  if (active) setLoading(false);
}
```

Keep the surrounding `useEffect`, `active` flag, cleanup, and the separate
Supabase session/auth effect. Keep the `supabase` import because this file
still uses it for session handling and `getPublicImageUrl()`.

In the promotions section, replace only the existing banner `<img>` with:

```tsx
<OfflineImage
  src={imageUrl}
  alt={banner.title}
  loading="lazy"
  className="h-full w-full object-cover"
  onError={() => markImageFailed(`banner-${banner.id}`)}
/>
```

Do not change the surrounding fallback banner markup or overlay.

### `src/components/ProductCard.tsx` (currently 263 lines)

Add:

```tsx
import { OfflineImage } from "@/components/OfflineImage";
```

Inside `ProductTile`, replace only the existing `<img>` with:

```tsx
<OfflineImage
  src={image}
  alt={p.name}
  loading="lazy"
  className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
/>
```

Keep the existing surrounding conditional and placeholder markup.

### `src/routes/product.$id.tsx` (currently 392 lines)

Add:

```tsx
import { OfflineImage } from "@/components/OfflineImage";
```

In `ProductGallery`, replace only the main gallery `<img>` with:

```tsx
<OfflineImage
  src={currentImage}
  alt={`${name} - View ${activeIndex + 1}`}
  className="h-full w-full object-contain p-3 transition-all duration-300"
/>
```

Replace only each thumbnail `<img>` with:

```tsx
<OfflineImage
  src={img}
  alt=""
  className="h-full w-full rounded-lg object-contain"
/>
```

Keep the gallery controls, active-index logic, wrappers, and thumbnail buttons
unchanged.

## Step 4 — build gate

After Step 1 only, run `bun run build`. If it fails, stop and send the full
error before applying any other step.

If it succeeds, add Step 2 and Step 3, then run `bun run build` again.

No Supabase schema, data, auth, or configuration changes are required.

## What this stage does not promise

- It does not make AI, checkout, authentication, live stock, or WhatsApp work
  without connectivity.
- Catalogue prices and stock are saved snapshots and may become stale.
- Images are saved only after they are viewed online; this does not pre-download
  the entire catalogue.
- The service worker caches the public home document and same-origin static
  scripts/styles/fonts only. It does not cache account/admin/API responses.
- A direct offline reload of a non-home route shows the generic offline page.
  The app can still navigate between routes while the already-open SPA remains
  loaded.
- This has not been run through your repository's build. The build gate above
  is required before proceeding.
